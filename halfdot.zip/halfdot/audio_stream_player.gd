extends AudioStreamPlayer


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	_on_playbutton_toggled(true)
	pass

func _on_playbutton_toggled(toggled_on: bool) -> void:
	pass # Replace with function body.
